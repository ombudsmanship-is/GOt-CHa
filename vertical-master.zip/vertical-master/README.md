# Vertical

“what's your favorite zef?”

| type of up | site URL link |
| ------------- | ------------- |
| | GitLitBit |
| | |
| wiki-up | Clifftop wiki page |
| static-up | Clifftop |
| | |
| wiki-up | Tri9vikrama’s [Scarecrow user page](http://scarecrow.referata.com/wiki/User:Tri9vikrama) |
| static-up | [Scarecrow of Oz](https://sites.google.com/site/tri9vikrama) Google Site |
| | |
| wiki-up | Shafar’s FANDOM [user page](https://shafar.fandom.com/wiki/User:Shafar) |
| static-up | Safari Roll20 [Campaign Forum](https://app.roll20.net/campaigns/forum/4167870) |
| | |
| base | Kranditri’s Wikipedia [user page](https://en.wikipedia.org/wiki/User:Kranditri) |
